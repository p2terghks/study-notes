variable "name" {
  type = string
}
variable "cidr" {
  type = string
}
variable "azs" {
  type = list(string)
}
variable "ha_nat" {
  type = bool
}
resource "aws_vpc" "this" {
  cidr_block           = var.cidr
  enable_dns_support   = true
  enable_dns_hostnames = true
  tags = {
    Name = var.name
  }
}
resource "aws_internet_gateway" "this" {
  vpc_id = aws_vpc.this.id
}
resource "aws_subnet" "public" {
  count             = 2
  vpc_id            = aws_vpc.this.id
  availability_zone = var.azs[count.index]
  cidr_block        = cidrsubnet(var.cidr, 8, count.index)
  tags = {
    Name = "${var.name}-public-${count.index}"
  }
}
resource "aws_subnet" "web" {
  count             = 2
  vpc_id            = aws_vpc.this.id
  availability_zone = var.azs[count.index]
  cidr_block        = cidrsubnet(var.cidr, 8, 10 + count.index)
  tags = {
    Name = "${var.name}-web-${count.index}"
  }
}
resource "aws_subnet" "app" {
  count             = 2
  vpc_id            = aws_vpc.this.id
  availability_zone = var.azs[count.index]
  cidr_block        = cidrsubnet(var.cidr, 8, 20 + count.index)
  tags = {
    Name = "${var.name}-app-${count.index}"
  }
}
resource "aws_subnet" "db" {
  count             = 2
  vpc_id            = aws_vpc.this.id
  availability_zone = var.azs[count.index]
  cidr_block        = cidrsubnet(var.cidr, 8, 30 + count.index)
  tags = {
    Name = "${var.name}-db-${count.index}"
  }
}
resource "aws_eip" "nat" {
  count  = var.ha_nat ? 2 : 1
  domain = "vpc"
}
resource "aws_nat_gateway" "this" {
  count         = var.ha_nat ? 2 : 1
  allocation_id = aws_eip.nat[count.index].id
  subnet_id     = aws_subnet.public[count.index].id
  depends_on    = [aws_internet_gateway.this]
}
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.this.id
  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.this.id
  }
}
resource "aws_route_table_association" "public" {
  count          = 2
  subnet_id      = aws_subnet.public[count.index].id
  route_table_id = aws_route_table.public.id
}
resource "aws_route_table" "private" {
  count  = 2
  vpc_id = aws_vpc.this.id
  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.this[var.ha_nat ? count.index : 0].id
  }
}
resource "aws_route_table_association" "web" {
  count          = 2
  subnet_id      = aws_subnet.web[count.index].id
  route_table_id = aws_route_table.private[count.index].id
}
resource "aws_route_table_association" "app" {
  count          = 2
  subnet_id      = aws_subnet.app[count.index].id
  route_table_id = aws_route_table.private[count.index].id
}
resource "aws_route_table" "db" {
  vpc_id = aws_vpc.this.id
}
resource "aws_route_table_association" "db" {
  count          = 2
  subnet_id      = aws_subnet.db[count.index].id
  route_table_id = aws_route_table.db.id
}
output "vpc_id" {
  value = aws_vpc.this.id
}
output "public_ids" {
  value = aws_subnet.public[*].id
}
output "web_ids" {
  value = aws_subnet.web[*].id
}
output "app_ids" {
  value = aws_subnet.app[*].id
}
output "db_ids" {
  value = aws_subnet.db[*].id
}
