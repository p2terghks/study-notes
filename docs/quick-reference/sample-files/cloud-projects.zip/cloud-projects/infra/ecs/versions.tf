terraform {
  required_version = ">= 1.13.0, < 2.0.0"
  required_providers {
    aws = {
      source = "hashicorp/aws", version = "~> 6.14.0"
    }
  }
  backend "s3" {
  }
}
provider "aws" {
  region = var.region
  default_tags {
    tags = {
      Project = "cloud-portfolio", Environment = var.environment, ManagedBy = "Terraform"
    }
  }
}
variable "region" {
  type    = string
  default = "ap-northeast-2"
}
variable "environment" {
  type = string
  validation {
    condition     = contains(["dev", "stg", "prd"], var.environment)
    error_message = "Use dev, stg or prd."
  }
}
