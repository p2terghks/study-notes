# Optional: use an existing GitHub OIDC provider (one per AWS account).
variable "github_oidc_provider_arn" {
  type    = string
  default = ""
}
variable "github_oidc_subject" {
  type        = string
  default     = ""
  description = "Exact sub for the configured GitHub environment, including immutable IDs if enabled."
}
variable "ecr_repository_arn" {
  type    = string
  default = ""
}
data "aws_caller_identity" "current" {
}
locals {
  enable_ci = var.github_oidc_provider_arn != ""
}
resource "aws_iam_role" "ci" {
  count = local.enable_ci ? 1 : 0
  name  = "${local.name}-github"
  assume_role_policy = jsonencode({
    Version = "2012-10-17", Statement = [{
      Effect = "Allow", Principal = {
        Federated = var.github_oidc_provider_arn
      },
      Action = "sts:AssumeRoleWithWebIdentity", Condition = {
        StringEquals = {
          "token.actions.githubusercontent.com:aud" = "sts.amazonaws.com", "token.actions.githubusercontent.com:sub" = var.github_oidc_subject
        }
      }
      }
    ]
    }
  )
  lifecycle {
    precondition {
      condition     = var.github_oidc_subject != "" && var.ecr_repository_arn != ""
      error_message = "Set the exact GitHub OIDC subject and ECR repository ARN."
    }
  }
}
resource "aws_iam_role_policy" "ci" {
  count = local.enable_ci ? 1 : 0
  role  = aws_iam_role.ci[0].id
  policy = jsonencode({
    Version = "2012-10-17", Statement = [
      {
        Effect = "Allow", Action = ["ecr:GetAuthorizationToken"], Resource = "*"
      },
      {
        Effect = "Allow", Action = ["ecr:BatchCheckLayerAvailability", "ecr:InitiateLayerUpload", "ecr:UploadLayerPart", "ecr:CompleteLayerUpload", "ecr:PutImage", "ecr:BatchGetImage", "ecr:GetDownloadUrlForLayer", "ecr:DescribeImages"], Resource = var.ecr_repository_arn
      },
      {
        Effect = "Allow", Action = ["ecs:DescribeTaskDefinition", "ecs:RegisterTaskDefinition"], Resource = "*"
      },
      {
        Effect = "Allow", Action = ["ecs:DescribeServices", "ecs:UpdateService"], Resource = aws_ecs_service.app.id
      },
      {
        Effect = "Allow", Action = ["ecs:RunTask"], Resource = "arn:aws:ecs:${var.region}:${data.aws_caller_identity.current.account_id}:task-definition/${aws_ecs_task_definition.app.family}:*", Condition = {
          ArnEquals = {
            "ecs:cluster" = aws_ecs_cluster.this.arn
          }
        }
      },
      {
        Effect = "Allow", Action = ["ecs:DescribeTasks"], Resource = "arn:aws:ecs:${var.region}:${data.aws_caller_identity.current.account_id}:task/${aws_ecs_cluster.this.name}/*"
      },
      {
        Effect = "Allow", Action = ["iam:PassRole"], Resource = [aws_iam_role.execution.arn, aws_iam_role.task.arn], Condition = {
          StringEquals = {
            "iam:PassedToService" = "ecs-tasks.amazonaws.com"
          }
        }
      }
    ]
    }
  )
}
output "github_role_arn" {
  value = try(aws_iam_role.ci[0].arn, null)
}
