mock_provider "aws" {}
run "rolling_release_plan" {
  command = plan
  variables {
    environment  = "dev"
    allowed_cidr = "203.0.113.7/32"
    image_uri    = "123456789012.dkr.ecr.ap-northeast-2.amazonaws.com/app@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  }
  assert {
    condition     = aws_ecs_service.app.deployment_minimum_healthy_percent == 100 && aws_ecs_service.app.deployment_maximum_percent == 200
    error_message = "Keep existing healthy tasks while starting new tasks."
  }
  assert {
    condition     = aws_ecs_service.app.network_configuration[0].assign_public_ip == false
    error_message = "App tasks must stay private."
  }
}
