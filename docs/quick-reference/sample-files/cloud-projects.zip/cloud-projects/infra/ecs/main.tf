resource "aws_security_group" "front" {
  name_prefix = "${local.name}-front-"
  vpc_id      = module.network.vpc_id
  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = [var.allowed_cidr]
  }
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [var.allowed_cidr]
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
resource "aws_lb" "front" {
  internal                   = false
  name                       = local.name
  load_balancer_type         = "application"
  subnets                    = module.network.public_ids
  security_groups            = [aws_security_group.front.id]
  drop_invalid_header_fields = true
}
resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.front.arn
  port              = 80
  protocol          = "HTTP"
  default_action {
    type             = var.certificate_arn == "" ? "forward" : "redirect"
    target_group_arn = var.certificate_arn == "" ? aws_lb_target_group.front.arn : null
    dynamic "redirect" {
      for_each = var.certificate_arn == "" ? [] : [1]
      content {
        port        = "443"
        protocol    = "HTTPS"
        status_code = "HTTP_301"
      }
    }
  }
}
resource "aws_lb_listener" "https" {
  count             = var.certificate_arn == "" ? 0 : 1
  load_balancer_arn = aws_lb.front.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = var.certificate_arn
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.front.arn
  }
}
output "url" {
  value = "${var.certificate_arn == "" ? "http" : "https"}://${aws_lb.front.dns_name}"
}
resource "aws_security_group" "app" {
  name_prefix = "${local.name}-app-"
  vpc_id      = module.network.vpc_id
  ingress {
    from_port       = 8080
    to_port         = 8080
    protocol        = "tcp"
    security_groups = [aws_security_group.front.id]
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
module "database" {
  source              = "../modules/database"
  name                = local.name
  vpc_id              = module.network.vpc_id
  subnet_ids          = module.network.db_ids
  client_sg           = aws_security_group.app.id
  multi_az            = var.multi_az
  deletion_protection = var.deletion_protection
}
output "db_identifier" {
  value = module.database.identifier
}
variable "desired_count" {
  type    = number
  default = 2
}
resource "aws_lb_target_group" "front" {
  name                 = local.name
  vpc_id               = module.network.vpc_id
  port                 = 8080
  protocol             = "HTTP"
  target_type          = "ip"
  deregistration_delay = 30
  health_check {
    path = "/readyz"
  }
}
resource "aws_ecs_cluster" "this" {
  name = local.name
}
resource "aws_cloudwatch_log_group" "app" {
  name              = "/portfolio/${local.name}"
  retention_in_days = 7
}
resource "aws_iam_role" "execution" {
  name = "${local.name}-execution"
  assume_role_policy = jsonencode({
    Version = "2012-10-17", Statement = [{
      Effect = "Allow", Principal = {
        Service = "ecs-tasks.amazonaws.com"
      },
      Action = "sts:AssumeRole"
      }
    ]
    }
  )
}
resource "aws_iam_role_policy_attachment" "execution" {
  role       = aws_iam_role.execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}
resource "aws_iam_role" "task" {
  name               = "${local.name}-task"
  assume_role_policy = aws_iam_role.execution.assume_role_policy
}
resource "aws_iam_role_policy" "secret" {
  role = aws_iam_role.task.id
  policy = jsonencode({
    Version = "2012-10-17", Statement = [{
      Effect = "Allow", Action = ["secretsmanager:GetSecretValue"], Resource = module.database.secret_arn
      }
    ]
    }
  )
}
resource "aws_ecs_task_definition" "app" {
  family                   = local.name
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = 256
  memory                   = 512
  execution_role_arn       = aws_iam_role.execution.arn
  task_role_arn            = aws_iam_role.task.arn
  runtime_platform {
    operating_system_family = "LINUX"
    cpu_architecture        = "X86_64"
  }
  container_definitions = jsonencode([{
    name = "app", image = var.image_uri, essential = true, stopTimeout = 30,
    portMappings = [{
      containerPort = 8080, protocol = "tcp"
      }
    ],
    environment = [
      {
        name = "DB_HOST", value = module.database.host
      },
      {
        name = "DB_NAME", value = "portfolio"
      },
      {
        name = "DB_SSL", value = "true"
      },
      {
        name = "DB_SECRET_ARN", value = module.database.secret_arn
      },
      {
        name = "AWS_REGION", value = var.region
      },
      {
        name = "APP_VERSION", value = var.image_uri
      }
    ],
    logConfiguration = {
      logDriver = "awslogs", options = {
        awslogs-group = aws_cloudwatch_log_group.app.name, awslogs-region = var.region, awslogs-stream-prefix = "app"
      }
    }
    }
  ])
}
resource "aws_ecs_service" "app" {
  name                               = local.name
  cluster                            = aws_ecs_cluster.this.id
  task_definition                    = aws_ecs_task_definition.app.arn
  desired_count                      = var.desired_count
  launch_type                        = "FARGATE"
  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent         = 200
  health_check_grace_period_seconds  = 120
  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }
  network_configuration {
    subnets          = module.network.app_ids
    security_groups  = [aws_security_group.app.id]
    assign_public_ip = false
  }
  load_balancer {
    target_group_arn = aws_lb_target_group.front.arn
    container_name   = "app"
    container_port   = 8080
  }
  # CI owns image revisions after bootstrap. Infrastructure and app release are separate.
  lifecycle {
    ignore_changes = [task_definition, desired_count]
  }
  depends_on = [aws_lb_listener.http, aws_lb_listener.https, module.network, aws_iam_role_policy_attachment.execution, aws_iam_role_policy.secret]
}
output "cluster" {
  value = aws_ecs_cluster.this.name
}
output "service" {
  value = aws_ecs_service.app.name
}
output "task_family" {
  value = aws_ecs_task_definition.app.family
}
output "task_role_arn" {
  value = aws_iam_role.task.arn
}
output "execution_role_arn" {
  value = aws_iam_role.execution.arn
}
output "network_configuration" {
  value = {
    awsvpcConfiguration = {
      subnets = module.network.app_ids, securityGroups = [aws_security_group.app.id], assignPublicIp = "DISABLED"
    }
  }
}
