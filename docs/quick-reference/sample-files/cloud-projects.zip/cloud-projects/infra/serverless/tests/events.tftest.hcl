mock_provider "aws" {}
run "versioned_event_pipeline_plan" {
  command = plan
  variables {
    environment = "dev"
  }
  assert {
    condition     = aws_s3_bucket_versioning.input.versioning_configuration[0].status == "Enabled"
    error_message = "Version IDs are required for deterministic event processing."
  }
  assert {
    condition     = aws_apigatewayv2_route.upload.authorization_type == "AWS_IAM"
    error_message = "The upload API must not allow anonymous uploads."
  }
}
