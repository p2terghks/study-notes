terraform {
  required_version = ">= 1.13.0, < 2.0.0"
  required_providers {
    aws = {
      source = "hashicorp/aws", version = "~> 6.14.0"
    }
  }
}
variable "region" {
  type    = string
  default = "ap-northeast-2"
}
variable "state_bucket_name" {
  type = string
}
variable "create_legacy_lock_table" {
  type    = bool
  default = false
}
provider "aws" {
  region = var.region
}
resource "aws_s3_bucket" "state" {
  bucket = var.state_bucket_name
  lifecycle {
    prevent_destroy = true
  }
}
resource "aws_s3_bucket_versioning" "state" {
  bucket = aws_s3_bucket.state.id
  versioning_configuration {
    status = "Enabled"
  }
}
resource "aws_s3_bucket_server_side_encryption_configuration" "state" {
  bucket = aws_s3_bucket.state.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}
resource "aws_s3_bucket_public_access_block" "state" {
  bucket                  = aws_s3_bucket.state.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}
resource "aws_s3_bucket_policy" "tls" {
  bucket = aws_s3_bucket.state.id
  policy = jsonencode({
    Version = "2012-10-17", Statement = [{
      Effect = "Deny", Principal = "*", Action = "s3:*", Resource = [aws_s3_bucket.state.arn, "${aws_s3_bucket.state.arn}/*"], Condition = {
        Bool = {
          "aws:SecureTransport" = "false"
        }
      }
      }
    ]
    }
  )
}
# Migration reference only: new deployments use S3 use_lockfile=true.
resource "aws_dynamodb_table" "legacy_lock" {
  count        = var.create_legacy_lock_table ? 1 : 0
  name         = "portfolio-legacy-state-lock"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "LockID"
  attribute {
    name = "LockID"
    type = "S"
  }
}
resource "aws_ecr_repository" "app" {
  name                 = "cloud-portfolio-app"
  image_tag_mutability = "IMMUTABLE"
  image_scanning_configuration {
    scan_on_push = true
  }
  encryption_configuration {
    encryption_type = "AES256"
  }
  force_delete = false
}
output "state_bucket" {
  value = aws_s3_bucket.state.id
}
output "repository_url" {
  value = aws_ecr_repository.app.repository_url
}
output "repository_arn" {
  value = aws_ecr_repository.app.arn
}
