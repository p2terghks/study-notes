mock_provider "aws" {
  mock_data "aws_ssm_parameter" {
    defaults = { value = "ami-0123456789abcdef0" }
  }
}
run "two_az_three_tier_plan" {
  command = plan
  variables {
    environment  = "dev"
    allowed_cidr = "203.0.113.7/32"
    image_uri    = "123456789012.dkr.ecr.ap-northeast-2.amazonaws.com/app@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  }
  assert {
    condition     = length(module.network.public_ids) == 2 && length(module.network.web_ids) == 2 && length(module.network.app_ids) == 2 && length(module.network.db_ids) == 2
    error_message = "Each tier must span two AZ subnets."
  }
  assert {
    condition     = aws_lb.internal.internal && !aws_lb.front.internal
    error_message = "Only the entry ALB may be internet-facing."
  }
}
