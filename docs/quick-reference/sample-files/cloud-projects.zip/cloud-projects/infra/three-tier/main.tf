resource "aws_security_group" "front" {
  name_prefix = "${local.name}-front-"
  vpc_id      = module.network.vpc_id
  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = [var.allowed_cidr]
  }
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [var.allowed_cidr]
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
resource "aws_lb" "front" {
  internal                   = false
  name                       = local.name
  load_balancer_type         = "application"
  subnets                    = module.network.public_ids
  security_groups            = [aws_security_group.front.id]
  drop_invalid_header_fields = true
}
resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.front.arn
  port              = 80
  protocol          = "HTTP"
  default_action {
    type             = var.certificate_arn == "" ? "forward" : "redirect"
    target_group_arn = var.certificate_arn == "" ? aws_lb_target_group.front.arn : null
    dynamic "redirect" {
      for_each = var.certificate_arn == "" ? [] : [1]
      content {
        port        = "443"
        protocol    = "HTTPS"
        status_code = "HTTP_301"
      }
    }
  }
}
resource "aws_lb_listener" "https" {
  count             = var.certificate_arn == "" ? 0 : 1
  load_balancer_arn = aws_lb.front.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = var.certificate_arn
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.front.arn
  }
}
output "url" {
  value = "${var.certificate_arn == "" ? "http" : "https"}://${aws_lb.front.dns_name}"
}
resource "aws_security_group" "web" {
  name_prefix = "${local.name}-web-"
  vpc_id      = module.network.vpc_id
  ingress {
    from_port       = 80
    to_port         = 80
    protocol        = "tcp"
    security_groups = [aws_security_group.front.id]
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
resource "aws_security_group" "internal" {
  name_prefix = "${local.name}-internal-"
  vpc_id      = module.network.vpc_id
  ingress {
    from_port       = 80
    to_port         = 80
    protocol        = "tcp"
    security_groups = [aws_security_group.web.id]
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
resource "aws_security_group" "app" {
  name_prefix = "${local.name}-app-"
  vpc_id      = module.network.vpc_id
  ingress {
    from_port       = 8080
    to_port         = 8080
    protocol        = "tcp"
    security_groups = [aws_security_group.internal.id]
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
module "database" {
  source              = "../modules/database"
  name                = local.name
  vpc_id              = module.network.vpc_id
  subnet_ids          = module.network.db_ids
  client_sg           = aws_security_group.app.id
  multi_az            = var.multi_az
  deletion_protection = var.deletion_protection
}
output "db_identifier" {
  value = module.database.identifier
}
resource "aws_lb_target_group" "front" {
  name                 = "${local.name}-web"
  vpc_id               = module.network.vpc_id
  port                 = 80
  protocol             = "HTTP"
  deregistration_delay = 30
  health_check {
    path = "/healthz"
  }
}
resource "aws_lb" "internal" {
  name               = "${local.name}-internal"
  internal           = true
  load_balancer_type = "application"
  subnets            = module.network.app_ids
  security_groups    = [aws_security_group.internal.id]
}
resource "aws_lb_target_group" "app" {
  name                 = "${local.name}-app"
  vpc_id               = module.network.vpc_id
  port                 = 8080
  protocol             = "HTTP"
  deregistration_delay = 30
  health_check {
    path = "/readyz"
  }
}
resource "aws_lb_listener" "internal" {
  load_balancer_arn = aws_lb.internal.arn
  port              = 80
  protocol          = "HTTP"
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.app.arn
  }
}
resource "aws_iam_role" "vm" {
  name = local.name
  assume_role_policy = jsonencode({
    Version = "2012-10-17", Statement = [{
      Effect = "Allow", Principal = {
        Service = "ec2.amazonaws.com"
      },
      Action = "sts:AssumeRole"
      }
    ]
    }
  )
}
resource "aws_iam_role_policy_attachment" "ssm" {
  role       = aws_iam_role.vm.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}
resource "aws_iam_role_policy_attachment" "ecr" {
  role       = aws_iam_role.vm.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
}
resource "aws_iam_role_policy" "secret" {
  role = aws_iam_role.vm.id
  policy = jsonencode({
    Version = "2012-10-17", Statement = [{
      Effect = "Allow", Action = ["secretsmanager:GetSecretValue"], Resource = module.database.secret_arn
      }
    ]
    }
  )
}
resource "aws_iam_instance_profile" "vm" {
  name = local.name
  role = aws_iam_role.vm.name
}
# Web instances need SSM only; they cannot retrieve DB secrets or ECR credentials.
resource "aws_iam_role" "web" {
  name               = "${local.name}-web"
  assume_role_policy = aws_iam_role.vm.assume_role_policy
}
resource "aws_iam_role_policy_attachment" "web_ssm" {
  role       = aws_iam_role.web.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}
resource "aws_iam_instance_profile" "web" {
  name = "${local.name}-web"
  role = aws_iam_role.web.name
}
module "app" {
  source            = "../modules/vm-tier"
  name              = "${local.name}-app"
  subnet_ids        = module.network.app_ids
  security_group_id = aws_security_group.app.id
  profile_name      = aws_iam_instance_profile.vm.name
  target_group_arn  = aws_lb_target_group.app.arn
  desired           = 2
  max_size          = 4
  user_data = templatefile("${path.module}/app-user-data.sh.tftpl", {
    image = var.image_uri, region = var.region, host = module.database.host, secret = module.database.secret_arn
    }
  )
  depends_on = [module.network, aws_iam_role_policy.secret, aws_iam_role_policy_attachment.ecr]
}
module "web" {
  source            = "../modules/vm-tier"
  name              = "${local.name}-web"
  subnet_ids        = module.network.web_ids
  security_group_id = aws_security_group.web.id
  profile_name      = aws_iam_instance_profile.web.name
  target_group_arn  = aws_lb_target_group.front.arn
  desired           = 2
  max_size          = 4
  user_data = templatefile("${path.module}/web-user-data.sh.tftpl", {
    upstream = aws_lb.internal.dns_name
    }
  )
  depends_on = [module.network]
}
output "app_asg" {
  value = module.app.asg_name
}
output "web_asg" {
  value = module.web.asg_name
}
