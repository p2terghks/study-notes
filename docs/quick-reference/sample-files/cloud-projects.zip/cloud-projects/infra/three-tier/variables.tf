variable "azs" {
  type    = list(string)
  default = ["ap-northeast-2a", "ap-northeast-2c"]
  validation {
    condition     = length(distinct(var.azs)) == 2
    error_message = "Exactly two distinct AZs are required."
  }
}
variable "vpc_cidr" {
  type    = string
  default = "10.40.0.0/16"
}
variable "allowed_cidr" {
  type        = string
  description = "Your public IPv4/32 or approved client range; no public-by-default demo writes."
  validation {
    condition     = can(cidrnetmask(var.allowed_cidr)) && var.allowed_cidr != "0.0.0.0/0"
    error_message = "Use a restricted IPv4 range for this unauthenticated lab."
  }
}
variable "image_uri" {
  type        = string
  description = "ECR image URI pinned by sha256 digest, built for linux/amd64."
  validation {
    condition     = can(regex("^[0-9]{12}\\.dkr\\.ecr\\.[a-z0-9-]+\\.amazonaws\\.com/.+@sha256:[a-f0-9]{64}$", var.image_uri))
    error_message = "Provide an immutable ECR image digest URI."
  }
}
variable "ha_nat" {
  type    = bool
  default = true
}
variable "multi_az" {
  type    = bool
  default = true
}
variable "deletion_protection" {
  type    = bool
  default = true
}
variable "certificate_arn" {
  type        = string
  default     = ""
  description = "ACM certificate in this region; empty enables restricted HTTP-only lab mode."
}
locals {
  name = "portfolio-${var.environment}-vm"
}
module "network" {
  source = "../modules/network"
  name   = local.name
  cidr   = var.vpc_cidr
  azs    = var.azs
  ha_nat = var.ha_nat
}
