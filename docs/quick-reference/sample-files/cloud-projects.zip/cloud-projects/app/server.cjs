const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

function memoryStore() {
  let rows = [];
  return {
    ready: async () => true,
    list: async () => rows.slice(-100).reverse(),
    add: async (text) => {
      const row = {id: rows.length + 1, text, created_at: new Date().toISOString()};
      rows.push(row); return row;
    }
  };
}

function postgresStore(env = process.env) {
  const {Client} = require('pg');
  let cached, expires = 0;
  async function config() {
    let auth = {username: env.DB_USER, password: env.DB_PASSWORD};
    if (env.DB_SECRET_ARN) {
      if (!cached || Date.now() >= expires) {
        const {SecretsManagerClient, GetSecretValueCommand} = require('@aws-sdk/client-secrets-manager');
        const client = new SecretsManagerClient({region: env.AWS_REGION});
        const response = await client.send(new GetSecretValueCommand({SecretId: env.DB_SECRET_ARN}));
        cached = JSON.parse(response.SecretString); expires = Date.now() + 60000;
        client.destroy();
      }
      auth = cached;
    }
    return {
      host: env.DB_HOST, port: Number(env.DB_PORT || 5432), database: env.DB_NAME || 'portfolio',
      user: auth.username, password: auth.password,
      connectionTimeoutMillis: 3000, query_timeout: 5000,
      ssl: env.DB_SSL === 'true' ? {rejectUnauthorized: true, ca: fs.readFileSync(env.DB_CA_FILE || '/app/rds-ca.pem', 'utf8')} : false
    };
  }
  async function query(sql, values = []) {
    const client = new Client(await config());
    try { await client.connect(); return await client.query(sql, values); }
    catch (error) { if (error.code === '28P01') expires = 0; throw error; }
    finally { await client.end().catch(() => {}); }
  }
  return {
    ready: async () => { await query('SELECT 1 FROM notes LIMIT 1'); return true; },
    list: async () => (await query('SELECT id, text, created_at FROM notes ORDER BY id DESC LIMIT 100')).rows,
    add: async (text) => (await query('INSERT INTO notes(text) VALUES($1) RETURNING id, text, created_at', [text])).rows[0],
    // Run once as a migration job before traffic. Not during HTTP requests.
    migrate: async () => query('BEGIN; SELECT pg_advisory_xact_lock(842019); CREATE TABLE IF NOT EXISTS notes (id BIGSERIAL PRIMARY KEY, text VARCHAR(200) NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP); COMMIT;')
  };
}

function createServer(store, env = process.env) {
  let draining = false;
  const server = http.createServer(async (req, res) => {
    const send = (status, body) => {
      res.writeHead(status, {'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store'});
      res.end(JSON.stringify(body));
    };
    try {
      const url = new URL(req.url, 'http://localhost');
      if (req.method === 'GET' && url.pathname === '/healthz') return send(200, {status: 'alive'});
      if (req.method === 'GET' && url.pathname === '/readyz') {
        if (draining) return send(503, {status: 'draining'});
        await store.ready(); return send(200, {status: 'ready'});
      }
      if (req.method === 'GET' && url.pathname === '/') {
        res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'});
        return res.end(fs.readFileSync(path.join(__dirname, 'public/index.html')));
      }
      if (req.method === 'GET' && url.pathname === '/api/info') return send(200, {version: env.APP_VERSION || 'local', instance: os.hostname()});
      if (req.method === 'GET' && url.pathname === '/api/notes') return send(200, await store.list());
      if (req.method === 'POST' && url.pathname === '/api/notes') {
        if (!req.headers['content-type']?.startsWith('application/json')) return send(415, {error: 'application/json required'});
        const chunks = []; let bytes = 0;
        for await (const chunk of req) {
          bytes += chunk.length;
          if (bytes > 4096) return send(413, {error: 'request too large'});
          chunks.push(chunk);
        }
        let value;
        try { value = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { return send(400, {error: 'invalid JSON'}); }
        const text = typeof value?.text === 'string' ? value.text.trim() : '';
        if (!text || text.length > 200) return send(400, {error: 'text must be 1..200 characters'});
        return send(201, await store.add(text));
      }
      return send(404, {error: 'not found'});
    } catch {
      console.error(JSON.stringify({event: 'request_failed', path: req.url}));
      return send(503, {error: 'service temporarily unavailable'});
    }
  });
  server.requestTimeout = 15000;
  server.headersTimeout = 10000;
  server.drain = () => { draining = true; server.close(); };
  return server;
}

if (require.main === module) {
  const store = process.env.STORE === 'memory' ? memoryStore() : postgresStore();
  if (process.argv.includes('--migrate')) {
    if (!store.migrate) throw new Error('Migration requires PostgreSQL');
    store.migrate().then(() => console.log('migration complete')).catch(() => { console.error('migration failed'); process.exitCode = 1; });
  } else {
    const server = createServer(store);
    server.listen(Number(process.env.PORT || 8080), '0.0.0.0');
    process.on('SIGTERM', () => { server.drain(); setTimeout(() => process.exit(0), 20000).unref(); });
  }
}
module.exports = {createServer, memoryStore};
