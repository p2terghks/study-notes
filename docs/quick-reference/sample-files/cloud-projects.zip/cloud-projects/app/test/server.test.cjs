const {test} = require('node:test');
const assert = require('node:assert/strict');
const {createServer, memoryStore} = require('../server.cjs');
async function serve(t, store = memoryStore()) {
  const server = createServer(store);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => server.close(resolve)));
  return `http://127.0.0.1:${server.address().port}`;
}
test('health, create/list, escaping boundary and input validation', async t => {
  const url = await serve(t);
  assert.equal((await fetch(url + '/readyz')).status, 200);
  const post = body => fetch(url + '/api/notes', {method:'POST', headers:{'Content-Type':'application/json'}, body});
  assert.equal((await post('{')).status, 400);
  assert.equal((await post('null')).status, 400);
  assert.equal((await post(JSON.stringify({text:' '.repeat(5)}))).status, 400);
  assert.equal((await post(JSON.stringify({text:'x'.repeat(201)}))).status, 400);
  assert.equal((await post(JSON.stringify({text:'<script>alert(1)</script>'}))).status, 201);
  const rows = await (await fetch(url + '/api/notes')).json();
  assert.equal(rows.length, 1); assert.equal(rows[0].text, '<script>alert(1)</script>');
  assert.equal((await fetch(url + '/missing')).status, 404);
});
test('DB outage changes readiness and requests, not liveness; no internal details leak', async t => {
  const fail = async () => { throw new Error('private password'); };
  const url = await serve(t, {ready:fail,list:fail});
  assert.equal((await fetch(url + '/healthz')).status, 200);
  assert.equal((await fetch(url + '/readyz')).status, 503);
  const r=await fetch(url + '/api/notes'); assert.equal(r.status,503); assert.ok(!(await r.text()).includes('password'));
});
