"""Real image transform using local object-store/table adapters. No AWS access."""
import io
import json
from pathlib import Path
from PIL import Image
from worker import process

ROOT = Path(__file__).resolve().parent / 'build/local'

class LocalS3:
    def get_object(self, Bucket, Key, VersionId):
        return {'Body': io.BytesIO((ROOT / 'source.png').read_bytes())}
    def put_object(self, Bucket, Key, Body, **kwargs):
        dest = ROOT / Key
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(Body)

class LocalTable:
    def __init__(self): self.rows = {}
    def get_item(self, Key, **kwargs):
        value = self.rows.get(Key['image_id'])
        return {'Item': value} if value else {}
    def put_item(self, Item, **kwargs):
        self.rows[Item['image_id']] = Item
        (ROOT/'metadata.json').write_text(json.dumps(self.rows, indent=2))

ROOT.mkdir(parents=True, exist_ok=True)
Image.new('RGB',(1000,600),'#276aa0').save(ROOT/'source.png')
event={'source':'aws.s3','detail-type':'Object Created','detail':{'bucket':{'name':'local-input'},'object':{'key':'uploads/demo.png','version-id':'demo-v1'}}}
s3, table = LocalS3(), LocalTable()
print(process(event,s3,table,'local-input','local-output'))
print(process(event,s3,table,'local-input','local-output'))
print(f'Generated thumbnail and metadata: {ROOT}')
