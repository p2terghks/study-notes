"""HTTP API route protected by AWS_IAM. No anonymous uploads."""
import json
import os
import uuid


def respond(status, body):
    return {'statusCode': status, 'headers': {'content-type': 'application/json'}, 'body': json.dumps(body)}


def issue_upload(event, s3, bucket):
    try:
        body = json.loads(event.get('body') or '{}')
        content_type = body.get('content_type')
    except (ValueError, AttributeError):
        return respond(400, {'error': 'invalid JSON'})
    if content_type not in ('image/png', 'image/jpeg'):
        return respond(400, {'error': 'content_type must be image/png or image/jpeg'})
    key = f'uploads/{uuid.uuid4()}'
    signed = s3.generate_presigned_post(
        Bucket=bucket, Key=key,
        Fields={'Content-Type': content_type},
        Conditions=[{'Content-Type': content_type}, ['content-length-range', 1, 5 * 1024 * 1024]],
        ExpiresIn=300)
    return respond(200, {'key': key, 'upload': signed})


def handler(event, context):
    import boto3
    return issue_upload(event, boto3.client('s3'), os.environ['INPUT_BUCKET'])
