import io
import json
import unittest
from unittest.mock import Mock
from PIL import Image
from worker import process, thumbnail
from api import issue_upload


def image_bytes(size=(800, 400)):
    out = io.BytesIO()
    Image.new('RGB', size, 'blue').save(out, 'PNG')
    return out.getvalue()


def event(version='v1', key='uploads/a+b 한글.png'):
    return {'source': 'aws.s3', 'detail-type': 'Object Created',
            'detail': {'bucket': {'name': 'input'}, 'object': {'key': key, 'version-id': version}}}


class WorkerTests(unittest.TestCase):
    def test_resize_and_small_image(self):
        data, w, h = thumbnail(image_bytes())
        self.assertEqual((w, h), (320, 160))
        self.assertEqual(Image.open(io.BytesIO(data)).format, 'JPEG')
        self.assertEqual(thumbnail(image_bytes((20, 10)))[1:], (20, 10))

    def test_invalid_or_large_image(self):
        with self.assertRaises(Exception): thumbnail(b'not an image')
        with self.assertRaises(ValueError): thumbnail(b'x' * (5 * 1024 * 1024 + 1))

    def test_versioned_identity_duplicate_and_out_of_order(self):
        s3 = Mock(); table = Mock(); stored = {}
        table.get_item.side_effect = lambda Key, **kw: {'Item': stored[Key['image_id']]} if Key['image_id'] in stored else {}
        table.put_item.side_effect = lambda Item, **kw: stored.update({Item['image_id']:Item})
        s3.get_object.side_effect = lambda **kw: {'Body': io.BytesIO(image_bytes())}
        newest = process(event('v2'), s3, table, 'input', 'output')
        oldest = process(event('v1'), s3, table, 'input', 'output')
        self.assertNotEqual(newest['image_id'], oldest['image_id'])
        self.assertEqual(process(event('v2'), s3, table, 'input', 'output')['status'], 'duplicate')
        self.assertEqual(s3.get_object.call_count, 2)
        self.assertEqual(s3.get_object.call_args.kwargs['Key'], 'uploads/a+b 한글.png')
        self.assertEqual(s3.get_object.call_args.kwargs['VersionId'], 'v1')

    def test_failure_after_upload_is_retryable(self):
        s3=Mock(); table=Mock(); table.get_item.return_value={}
        s3.get_object.side_effect=lambda **kw:{'Body':io.BytesIO(image_bytes())}
        table.put_item.side_effect=[RuntimeError('DB unavailable'), None]
        with self.assertRaises(RuntimeError): process(event(),s3,table,'input','output')
        self.assertEqual(process(event(),s3,table,'input','output')['status'],'complete')
        self.assertEqual(s3.put_object.call_args_list[0].kwargs['Key'],s3.put_object.call_args_list[1].kwargs['Key'])

    def test_filters_and_version_requirement(self):
        s3=Mock(); table=Mock()
        self.assertEqual(process(event(key='thumbnails/x'),s3,table,'input','output')['status'],'ignored')
        self.assertEqual(process(event(),s3,table,'different-input','output')['status'],'ignored')
        with self.assertRaises(ValueError): process(event(version='null'),s3,table,'input','output')
        s3.get_object.assert_not_called()

    def test_upload_validation_and_policy(self):
        s3=Mock(); s3.generate_presigned_post.return_value={'url':'https://example.test','fields':{}}
        self.assertEqual(issue_upload({'body':'null'},s3,'input')['statusCode'],400)
        self.assertEqual(issue_upload({'body':'{"content_type":"text/plain"}'},s3,'input')['statusCode'],400)
        result=issue_upload({'body':'{"content_type":"image/png"}'},s3,'input')
        self.assertEqual(result['statusCode'],200)
        self.assertIn(['content-length-range',1,5242880],s3.generate_presigned_post.call_args.kwargs['Conditions'])

if __name__=='__main__': unittest.main()
