"""Version-addressed thumbnails: duplicates and out-of-order events are harmless."""
import hashlib
import io
import json
import os
import warnings
from PIL import Image, ImageOps, UnidentifiedImageError

MAX_BYTES = 5 * 1024 * 1024
Image.MAX_IMAGE_PIXELS = 20_000_000


def thumbnail(raw):
    if len(raw) > MAX_BYTES:
        raise ValueError('image exceeds 5 MiB')
    with warnings.catch_warnings():
        warnings.simplefilter('error', Image.DecompressionBombWarning)
        with Image.open(io.BytesIO(raw)) as source:
            if source.format not in ('JPEG', 'PNG'):
                raise ValueError('only JPEG and PNG are supported')
            source.load()
            image = ImageOps.exif_transpose(source).convert('RGB')
            image.thumbnail((320, 320))
            output = io.BytesIO()
            image.save(output, format='JPEG', quality=85)
            return output.getvalue(), image.width, image.height


def process(event, s3, table, input_bucket, output_bucket):
    if event.get('source') != 'aws.s3' or event.get('detail-type') != 'Object Created':
        return {'status': 'ignored'}
    detail = event['detail']
    bucket = detail['bucket']['name']
    obj = detail['object']
    # EventBridge keys are used exactly as received; no unquote_plus double decoding.
    key = obj['key']
    if bucket != input_bucket or not key.startswith('uploads/'):
        return {'status': 'ignored'}
    version = obj.get('version-id')
    if not version or version == 'null':
        raise ValueError('source versioning and version-id are required')
    if obj.get('size', 0) > MAX_BYTES:
        raise ValueError('image exceeds 5 MiB')
    identity = json.dumps([bucket, key, version], ensure_ascii=False, separators=(',', ':'))
    image_id = hashlib.sha256(identity.encode()).hexdigest()
    existing = table.get_item(Key={'image_id': image_id}, ConsistentRead=True)
    if 'Item' in existing:
        return {'status': 'duplicate', 'image_id': image_id}
    response = s3.get_object(Bucket=bucket, Key=key, VersionId=version)
    body = response['Body']
    try:
        data = body.read(MAX_BYTES + 1)
    finally:
        body.close()
    encoded, width, height = thumbnail(data)
    output_key = f'thumbnails/{image_id}.jpg'
    s3.put_object(Bucket=output_bucket, Key=output_key, Body=encoded,
                  ContentType='image/jpeg', ServerSideEncryption='AES256')
    item = {'image_id': image_id, 'source_key': key, 'source_version': version,
            'output_key': output_key, 'width': width, 'height': height,
            'bytes': len(encoded)}
    try:
        table.put_item(Item=item, ConditionExpression='attribute_not_exists(image_id)')
    except Exception as error:
        if getattr(error, 'response', {}).get('Error', {}).get('Code') != 'ConditionalCheckFailedException':
            raise
    # Retry after an S3-success / DynamoDB-failure safely rewrites the same thumbnail.
    print(json.dumps({'event': 'thumbnail_complete', 'image_id': image_id}))
    return {'status': 'complete', 'image_id': image_id}


def handler(event, context):
    import boto3
    return process(event, boto3.client('s3'),
                   boto3.resource('dynamodb').Table(os.environ['TABLE_NAME']),
                   os.environ['INPUT_BUCKET'], os.environ['OUTPUT_BUCKET'])
