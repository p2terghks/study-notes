# 클라우드 포트폴리오 · 네 프로젝트

요청 범위: **가이드·전체 코드·로컬 실습**. AWS 리소스를 생성하거나 GitHub에 게시하지 않았습니다. AWS 부분은 계정 없이 Terraform 정적 검증까지 수행하고, 실제 리소스·장애·배포 검증은 구분해 기록합니다.

| 프로젝트 | 가이드 | 주요 코드 |
|---|---|---|
| 1. 3-Tier 고가용성 | [가이드](docs/01-ha.md) | compose.yaml, app/, web/, infra/three-tier/ |
| 2. Terraform IaC | [가이드](docs/02-iac.md) | infra/bootstrap/, infra/modules/, 환경별 tfvars·backend 예시 |
| 3. Docker·CI/CD | [가이드](docs/03-cicd.md) | app/Dockerfile, scripts/deploy-ecs.py, workflows/ |
| 4. 서버리스 이미지 처리 | [가이드](docs/04-serverless.md) | serverless/, infra/serverless/ |

## 로컬 웹 실습

Docker Desktop을 실행한 뒤 이 README가 있는 `cloud-projects` 폴더에서 실행합니다.

```bash
docker compose up -d --build --scale app=2
```

브라우저: <http://localhost:8088>. DB는 호스트에 포트를 공개하지 않으며 노트는 Docker 볼륨에 저장됩니다. 앱에는 로그인 기능이 없으므로 로컬 바인딩을 유지합니다.

```bash
curl -fsS http://localhost:8088/readyz
curl -fsS http://localhost:8088/api/info
curl -fsS -H 'Content-Type: application/json' -d '{"text":"첫 클라우드 실습"}' http://localhost:8088/api/notes
curl -fsS http://localhost:8088/api/notes
python3 scripts/probe.py http://localhost:8088/api/notes --count 30
```

종료: `docker compose down` (노트 유지). **노트까지 지울 때만** `docker compose down -v`를 실행합니다. Docker가 없어도 `STORE=memory node app/server.cjs`로 메모리 데모를 실행할 수 있습니다. 메모리 모드는 종료하면 데이터가 사라지고 3-Tier 검증에 해당하지 않습니다.

## 로컬 서버리스 실습

Python 3.12 이상을 사용합니다.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r serverless/requirements.txt
PYTHONPATH=serverless python -m unittest discover -s serverless/tests -v
python serverless/local_demo.py
```

`serverless/build/local/`에 원본·썸네일·metadata.json이 생성됩니다. 이미지 변환은 실제 실행하지만 S3·EventBridge·DynamoDB는 로컬 어댑터와 테스트 대역을 사용합니다.

## 코드 검증

```bash
node --test app/test/*.test.cjs
python3 scripts/test_deploy.py
terraform fmt -check -recursive infra
```

Terraform 1.13 이상(검증 버전 1.13.5), AWS provider 6.14 계열을 사용합니다. `.terraform.lock.hcl`과 `app/package-lock.json`, `serverless/requirements.txt`를 함께 관리하세요. `infra/serverless` 검증 전 `scripts/package-lambda.sh`로 Linux x86_64/Python 3.12용 ZIP을 만듭니다.

```bash
./scripts/package-lambda.sh
terraform -chdir=infra/bootstrap init -backend=false
terraform -chdir=infra/bootstrap validate
terraform -chdir=infra/three-tier init -backend=false
terraform -chdir=infra/three-tier validate
terraform -chdir=infra/ecs init -backend=false
terraform -chdir=infra/ecs validate
terraform -chdir=infra/serverless init -backend=false
terraform -chdir=infra/serverless validate
```

`init`는 프로바이더 다운로드를 위해 인터넷을 사용합니다. `terraform test`는 제공된 mock provider 테스트로 AWS API 없이 네트워크 분리·롤링 설정·버전 이벤트 구성을 확인합니다. 각 스택에서 `terraform test`로 실행할 수 있습니다.

`validate` 통과는 AWS 배포 성공을 의미하지 않습니다. 리전별 RDS 버전·인스턴스 지원, 할당량·IAM·ACM·실제 비용은 배포 시 확인해야 합니다.

## 예제의 경계

- 3-Tier는 외부 ALB → 웹 EC2 ASG → 내부 ALB → 앱 EC2 ASG → RDS입니다. 웹·앱·DB를 각각 구분합니다.
- ECS는 같은 앱을 Fargate에서 배포하는 별도 스택입니다. EC2 스택과 동시에 만들 필요가 없습니다.
- AWS 데모는 접근 CIDR을 제한합니다. HTTPS는 동일 리전 ACM ARN과 인증서에 맞는 도메인 DNS를 설정합니다.
- RDS 관리 암호는 Secrets Manager로 관리하며 코드·tfvars에 넣지 않습니다. 이 학습용 구성은 초기 스키마 생성과 앱에서 관리 사용자 자격증명을 공유합니다. 실제 운영에는 마이그레이션 전용 역할과 최소 권한 앱 DB 사용자를 분리해야 합니다.
- DB 연결은 요청별로 열고 닫는 교육용 구현입니다. 대규모 부하에는 커넥션 풀/RDS Proxy·재시도 정책·인증·요청 제한을 추가하고 다시 측정합니다.
- `/healthz`는 프로세스 생존, `/readyz`는 테이블 접근 가능 여부입니다. RDS failover 중 오류가 0이라는 보장은 하지 않습니다.
- `workflows/*.example`은 실행되지 않는 템플릿입니다. 설정을 완료하고 `.github/workflows`에 옮겨야 활성화됩니다.

[검증 기록](evidence/validation.md)을 확인하고 실제 관찰값과 추후 AWS 실습 항목을 구분하세요.
