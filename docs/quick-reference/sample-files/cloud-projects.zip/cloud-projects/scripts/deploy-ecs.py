"""Explicit release command for a provisioned ECS service. Never run by local tests."""
import json
import os
import subprocess
import sys

REGISTER_FIELDS = {'family','taskRoleArn','executionRoleArn','networkMode','containerDefinitions',
                   'volumes','placementConstraints','requiresCompatibilities','cpu','memory',
                   'pidMode','ipcMode','proxyConfiguration','inferenceAccelerators','ephemeralStorage','runtimePlatform'}


def release_definition(original, image):
    new = {k: v for k, v in original.items() if k in REGISTER_FIELDS}
    new = json.loads(json.dumps(new))
    found = False
    for container in new['containerDefinitions']:
        if container['name'] == 'app':
            found = True
            container['image'] = image
            env = [v for v in container.get('environment', []) if v['name'] != 'APP_VERSION']
            container['environment'] = env + [{'name':'APP_VERSION','value':image}]
    if not found: raise ValueError('app container missing')
    return new


def aws(*args):
    result = subprocess.run(['aws',*args,'--output','json'], check=True, text=True, capture_output=True)
    return json.loads(result.stdout) if result.stdout.strip() else {}


def main():
    cluster, service, image = (os.environ[k] for k in ['ECS_CLUSTER','ECS_SERVICE','IMAGE_URI'])
    if '@sha256:' not in image: raise ValueError('Use an image pinned by digest')
    current = aws('ecs','describe-services','--cluster',cluster,'--services',service)['services'][0]
    original = aws('ecs','describe-task-definition','--task-definition',current['taskDefinition'])['taskDefinition']
    definition = release_definition(original,image)
    new_arn = aws('ecs','register-task-definition','--cli-input-json',json.dumps(definition))['taskDefinition']['taskDefinitionArn']
    run = aws('ecs','run-task','--cluster',cluster,'--launch-type','FARGATE','--task-definition',new_arn,
              '--network-configuration',json.dumps(current['networkConfiguration']),
              '--overrides',json.dumps({'containerOverrides':[{'name':'app','command':['node','server.cjs','--migrate']}]}))
    if run.get('failures') or not run.get('tasks'): raise RuntimeError('Migration task could not start')
    task = run['tasks'][0]['taskArn']
    aws('ecs','wait','tasks-stopped','--cluster',cluster,'--tasks',task)
    details = aws('ecs','describe-tasks','--cluster',cluster,'--tasks',task)['tasks'][0]
    if not details.get('containers') or any(c.get('exitCode') != 0 for c in details['containers']):
        raise RuntimeError('Migration failed; service was not updated')
    aws('ecs','update-service','--cluster',cluster,'--service',service,'--task-definition',new_arn,'--desired-count','2')
    aws('ecs','wait','services-stable','--cluster',cluster,'--services',service)
    final = aws('ecs','describe-services','--cluster',cluster,'--services',service)['services'][0]
    primary = next(d for d in final['deployments'] if d['status'] == 'PRIMARY')
    if primary['taskDefinition'] != new_arn or primary.get('rolloutState') != 'COMPLETED':
        raise RuntimeError('Deployment rolled back or did not complete')
    print(json.dumps({'status':'released','task_definition':new_arn,'previous':current['taskDefinition']}))

if __name__ == '__main__': main()
