#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../serverless"
python3 - <<'PY'
from pathlib import Path
import shutil
shutil.rmtree(Path('build/package'), ignore_errors=True)
PY
# The deployment target is Linux x86_64 / Python 3.12, even on an Apple Silicon Mac.
python3 -m pip install --requirement requirements.txt --target build/package \
  --platform manylinux2014_x86_64 --implementation cp --python-version 3.12 \
  --only-binary=:all: --upgrade
cp worker.py api.py build/package/
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path('build/package')
with ZipFile('build/function.zip','w',ZIP_DEFLATED) as archive:
    for file in sorted(root.rglob('*')):
        if file.is_file() and '__pycache__' not in file.parts:
            archive.write(file,file.relative_to(root))
print('Created serverless/build/function.zip')
PY
