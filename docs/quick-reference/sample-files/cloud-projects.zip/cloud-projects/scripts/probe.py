"""Sequential availability probe; no load is sent beyond the specified URL/count."""
import argparse
import csv
import time
from urllib.request import urlopen
from urllib.error import HTTPError, URLError
p=argparse.ArgumentParser()
p.add_argument('url')
p.add_argument('--count',type=int,default=30)
p.add_argument('--interval',type=float,default=1.0)
p.add_argument('--output',default='evidence/probe.csv')
a=p.parse_args()
if a.count < 1 or a.interval < 0.1: p.error('count>=1 and interval>=0.1 required')
rows=[]
for _ in range(a.count):
    start=time.monotonic();status=0
    try:
        with urlopen(a.url,timeout=3) as r:status=r.status;r.read()
    except HTTPError as error:status=error.code
    except (URLError,TimeoutError,OSError):pass
    rows.append({'timestamp':time.time(),'status':status,'latency_ms':round((time.monotonic()-start)*1000,2)})
    time.sleep(a.interval)
with open(a.output,'w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
failures=sum(r['status']!=200 for r in rows)
print(f'{len(rows)} requests; {failures} failures; evidence: {a.output}')
