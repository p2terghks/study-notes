"""Optional AWS client: IAM-signed API request then a size-limited presigned upload."""
import argparse
import json
import mimetypes
import uuid
from pathlib import Path
from urllib.request import Request, urlopen
import boto3
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest

parser=argparse.ArgumentParser()
parser.add_argument('api_url')
parser.add_argument('image',type=Path)
parser.add_argument('--region',default='ap-northeast-2')
args=parser.parse_args()
content_type=mimetypes.guess_type(args.image.name)[0]
raw=args.image.read_bytes()
if content_type not in ('image/png','image/jpeg') or not 0<len(raw)<=5*1024*1024:
    parser.error('Use a JPEG/PNG of at most 5 MiB')
url=args.api_url.rstrip('/')+'/uploads'
body=json.dumps({'content_type':content_type}).encode()
session=boto3.Session(region_name=args.region)
credentials=session.get_credentials()
if credentials is None:parser.error('AWS credentials are required for this optional cloud command')
req=AWSRequest(method='POST',url=url,data=body,headers={'Content-Type':'application/json'})
SigV4Auth(credentials.get_frozen_credentials(),'execute-api',args.region).add_auth(req)
with urlopen(Request(url,data=body,headers=dict(req.headers)),timeout=15) as response:
    signed=json.load(response)
boundary=uuid.uuid4().hex
parts=[]
for key,value in signed['upload']['fields'].items():
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode())
parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="image"\r\nContent-Type: {content_type}\r\n\r\n'.encode()+raw+b'\r\n')
parts.append(f'--{boundary}--\r\n'.encode())
with urlopen(Request(signed['upload']['url'],data=b''.join(parts),headers={'Content-Type':f'multipart/form-data; boundary={boundary}'}),timeout=30) as response:
    print(json.dumps({'status':response.status,'source_key':signed['key']}))
