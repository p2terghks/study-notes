import importlib.util
from pathlib import Path
import unittest
spec=importlib.util.spec_from_file_location('deploy',Path(__file__).with_name('deploy-ecs.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class ReleaseTest(unittest.TestCase):
    def test_revision_filters_read_only_fields_and_preserves_sidecars(self):
        original={'family':'demo','revision':7,'taskDefinitionArn':'old','containerDefinitions':[{'name':'app','image':'old','environment':[{'name':'DB_HOST','value':'db'}]},{'name':'sidecar','image':'keep'}]}
        new=m.release_definition(original,'repo@sha256:new')
        self.assertNotIn('revision',new)
        self.assertEqual(new['containerDefinitions'][0]['image'],'repo@sha256:new')
        self.assertEqual(new['containerDefinitions'][1]['image'],'keep')
        self.assertEqual(original['containerDefinitions'][0]['image'],'old')
if __name__=='__main__':unittest.main()
