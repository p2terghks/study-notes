# CI/CD · 클라우드 실무 설정 템플릿

이 묶음은 완성된 Spring/React 앱이 아닙니다. 요약 HTML과 함께 사용하세요.
실제 AWS 배포는 수행하지 않았으며 리소스와 권한은 별도로 준비해야 합니다.

1. backend에 Maven Wrapper 기반 Spring Boot 앱(JDK 21), frontend에 React/Vite 앱(Node 22)을 준비합니다.
2. frontend의 package.json에 lint, test:ci, build 스크립트와 도구를 설치합니다.
3. compose.yaml과 .env.example을 루트에 복사합니다. .env를 만들고 로컬 DB 비밀번호를 바꿉니다.
4. docker compose up -d --wait db로 DB를 준비합니다. Java 프로세스에는 DB_URL/DB_USER/DB_PASSWORD를 따로 전달합니다.
5. ci.yml.example을 검토하고 .github/workflows/ci.yml에 복사합니다. 실제 테스트/빌드 성공을 먼저 확인하세요.
6. Dockerfile.example과 dockerignore.example을 backend/Dockerfile, backend/.dockerignore로 복사합니다. Maven finalName을 app으로 설정합니다.
7. launch.json.example은 VS Code 실행 설정 예시입니다. mainClass와 개인 환경값을 바꿉니다.
8. oidc-trust.json.example은 실제 계정 ID와 검증한 GitHub subject를 넣을 IAM trust policy 템플릿입니다.
9. cd-steps.yml.example은 전체 workflow가 아닙니다. 인증·이미지 게시·DB migration 후 단계입니다. IMAGE_URI(digest), AWS_REGION, ECS_CLUSTER, ECS_SERVICE와 task-definition 파일이 필요합니다.
10. scripts/verify-release.py를 프로젝트의 scripts/에 복사합니다. ECS rolling 배포에만 사용합니다.

## AWS 없이 검증기 테스트

python3 -m unittest discover -s scripts -p 'test_*.py' -v

## 조회 결과 검증

python3 scripts/verify-release.py service.json EXPECTED_TASK_ARN

service.json은 aws ecs describe-services의 결과입니다. 이 검증기는 파일만 읽습니다.
자동 롤백 후 이전 revision으로 안정화된 상태를 성공으로 처리하지 않습니다.
실제 배포에서는 추가로 HTTP 스모크 테스트와 오류율 관찰이 필요합니다.
