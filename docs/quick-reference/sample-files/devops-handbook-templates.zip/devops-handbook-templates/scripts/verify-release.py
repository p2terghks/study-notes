#!/usr/bin/env python3
"""Verify an ECS rolling release using a saved describe-services response."""
import json
import sys

def verify(payload, expected):
    if payload.get("failures"):
        raise ValueError("ECS 조회 실패")
    services = payload.get("services", [])
    if len(services) != 1:
        raise ValueError("서비스를 하나만 조회해야 합니다")
    service = services[0]
    deployments = service.get("deployments", [])
    if len(deployments) != 1:
        raise ValueError("교체 중인 deployment가 남아 있습니다")
    deployment = deployments[0]
    if service.get("status") != "ACTIVE":
        raise ValueError("서비스가 ACTIVE 상태가 아닙니다")
    if deployment.get("status") != "PRIMARY":
        raise ValueError("PRIMARY deployment가 아닙니다")
    if service.get("taskDefinition") != expected:
        raise ValueError("서비스 revision 불일치: 롤백 여부 확인")
    if deployment.get("taskDefinition") != expected:
        raise ValueError("deployment revision 불일치")
    if deployment.get("rolloutState") != "COMPLETED":
        raise ValueError("롤링 배포가 완료되지 않았습니다")
    desired = service.get("desiredCount", 0)
    if desired < 1 or service.get("runningCount") != desired:
        raise ValueError("목표 태스크 개수에 도달하지 못했습니다")
    if service.get("pendingCount") != 0:
        raise ValueError("시작 대기 태스크가 있습니다")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("usage: verify-release.py service.json EXPECTED_TASK_ARN")
    try:
        with open(sys.argv[1], encoding="utf-8") as source:
            verify(json.load(source), sys.argv[2])
    except (OSError, ValueError, TypeError, AttributeError) as error:
        print(f"Release check failed: {error}", file=sys.stderr)
        sys.exit(1)
    print("Expected ECS rolling release is active and completed.")
