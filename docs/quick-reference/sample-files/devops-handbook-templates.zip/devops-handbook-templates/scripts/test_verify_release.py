import copy
import importlib.util
from pathlib import Path
import unittest
spec = importlib.util.spec_from_file_location("verify_release", Path(__file__).with_name("verify-release.py"))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class VerifyReleaseTest(unittest.TestCase):
    def setUp(self):
        self.payload = {"services": [{"status": "ACTIVE", "taskDefinition": "new:2", "desiredCount": 2, "runningCount": 2, "pendingCount": 0, "deployments": [{"status": "PRIMARY", "taskDefinition": "new:2", "rolloutState": "COMPLETED"}]}]}
    def test_completed_expected_revision_passes(self):
        module.verify(self.payload, "new:2")
    def test_stable_rollback_fails(self):
        service=self.payload["services"][0]
        service["taskDefinition"]="old:1"
        service["deployments"][0]["taskDefinition"]="old:1"
        with self.assertRaises(ValueError): module.verify(self.payload,"new:2")
    def test_unhealthy_states_fail(self):
        for key,value in [("status","DRAINING"),("desiredCount",0),("runningCount",1),("pendingCount",1)]:
            with self.subTest(key=key):
                payload=copy.deepcopy(self.payload)
                payload["services"][0][key]=value
                with self.assertRaises(ValueError): module.verify(payload,"new:2")
    def test_incomplete_rollout_fails(self):
        self.payload["services"][0]["deployments"][0]["rolloutState"]="IN_PROGRESS"
        with self.assertRaises(ValueError): module.verify(self.payload,"new:2")
    def test_overlapping_deployments_fail(self):
        self.payload["services"][0]["deployments"].append({"status":"ACTIVE"})
        with self.assertRaises(ValueError): module.verify(self.payload,"new:2")
    def test_missing_service_and_api_failures(self):
        for payload in [{},{"services":[]},{"failures":[{"reason":"MISSING"}]}]:
            with self.subTest(payload=payload):
                with self.assertRaises(ValueError): module.verify(payload,"new:2")
if __name__ == "__main__": unittest.main()
