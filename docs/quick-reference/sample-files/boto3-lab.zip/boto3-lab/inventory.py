"""S3 read-only inventory. Running without arguments only displays help."""
import argparse
import json
import re
import sys

import boto3
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError


def iter_objects(client, bucket, prefix=""):
    paginator = client.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for item in page.get("Contents", []):
            yield {"Key": item["Key"], "Size": item["Size"]}


def summarize(client, bucket, prefix=""):
    # Learning example: all results are held in memory. Stream for large buckets.
    objects = list(iter_objects(client, bucket, prefix))
    return {"bucket": bucket, "prefix": prefix, "count": len(objects),
            "total_bytes": sum(x["Size"] for x in objects), "objects": objects}


def verify_account(sts, expected):
    actual = sts.get_caller_identity()["Account"]
    if actual != expected:
        raise ValueError(f"계정 불일치: expected={expected}, actual={actual}")


def main(argv=None):
    parser = argparse.ArgumentParser(description="S3 객체 목록 읽기 (업로드/삭제 없음)")
    parser.add_argument("--bucket", required=True)
    parser.add_argument("--region", required=True)
    parser.add_argument("--expected-account", required=True)
    parser.add_argument("--profile", help="생략하면 기본 자격증명 체인 사용")
    parser.add_argument("--prefix", default="")
    args_list = sys.argv[1:] if argv is None else argv
    if not args_list:
        parser.print_help()
        return 0
    args = parser.parse_args(args_list)
    if not re.fullmatch(r"\d{12}", args.expected_account):
        parser.error("--expected-account에는 12자리 AWS 계정 ID가 필요합니다")
    try:
        session = boto3.Session(profile_name=args.profile, region_name=args.region)
        config = Config(connect_timeout=5, read_timeout=30,
                        retries={"mode": "standard", "total_max_attempts": 4})
        verify_account(session.client("sts", config=config), args.expected_account)
        result = summarize(session.client("s3", config=config), args.bucket, args.prefix)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except ClientError as exc:
        print(f"AWS 오류: {exc.response['Error']['Code']}", file=sys.stderr)
    except (BotoCoreError, ValueError) as exc:
        print(f"실행 오류: {exc}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
