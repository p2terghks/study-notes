# Boto3 S3 목록 실습

Python 3.10 이상 권장. 이 폴더에서 실행합니다.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python inventory.py
```

Windows PowerShell 활성화: `.venv\Scripts\Activate.ps1`.
인수 없는 실행은 도움말만 표시합니다. 테스트는 가짜 자격증명과 Stubber를 쓰므로 AWS 계정이나 네트워크가 필요 없습니다 (패키지 설치에는 네트워크 필요).

## 실제 계정 조회 (선택)

```bash
aws configure sso --profile study
aws sso login --profile study
python inventory.py --bucket YOUR_BUCKET --profile study --region ap-northeast-2 --expected-account YOUR_12_DIGIT_ACCOUNT_ID --prefix reports/
```

자리표시자를 실제 값으로 바꿉니다. 먼저 STS 계정이 예상 계정과 일치하는지 확인하고 S3를 조회합니다. 버킷 소유 계정까지 검증하는 기능은 아닙니다. IAM 역할을 사용하는 실행 환경에서는 --profile을 생략합니다. 대상 버킷에 s3:ListBucket 권한이 필요합니다. 권한 경계, 버킷 정책, 조직 SCP도 실제 접근에 영향을 줍니다. 업로드/다운로드/삭제/생성은 하지 않지만 실제 목록 요청에는 서비스 요금이 적용될 수 있습니다.

출력 예:
```json
{"bucket":"example","prefix":"reports/","count":2,"total_bytes":30,"objects":[{"Key":"reports/a.csv","Size":10},{"Key":"reports/b.csv","Size":20}]}
```

paginator가 다음 토큰을 전달합니다. 빈 목록은 0개이며 AccessDenied는 빈 목록으로 숨기지 않고 실패 종료 코드 1을 반환합니다. 이 학습 예제는 목록을 메모리에 모으므로 대규모 버킷은 iter_objects를 사용해 한 객체씩 파일에 기록하도록 확장하세요. 동시 변경이 있는 버킷의 원자적 스냅샷을 보장하지 않습니다.
