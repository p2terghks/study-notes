# 검증 기록

- 문서 작성일: 2026-10-13
- Python 3.13 가상환경, boto3 1.43.112 / botocore 1.43.112
- `python -m unittest -v`: 5개 통과
- 검증: 빈 목록, 두 페이지의 ContinuationToken 전달과 합계, AccessDenied 오류 전달, 계정 불일치 차단, 인수 없는 실행에서 Session 생성 없음
- Stubber와 가짜 자격증명 사용. 실제 AWS API 호출 없음.
- 실제 IAM, 서비스 연결, 대상 버킷의 데이터 조회는 검증하지 않았습니다.
- requirements.txt는 검증 환경의 전체 의존성 버전을 고정합니다.
