import contextlib
import io
import unittest
from unittest.mock import patch
import boto3
from botocore.exceptions import ClientError
from botocore.stub import Stubber
from inventory import summarize, verify_account, main


def client(service):
    return boto3.client(service, region_name="ap-northeast-2",
                        aws_access_key_id="testing", aws_secret_access_key="testing")


class InventoryTests(unittest.TestCase):
    def test_empty(self):
        s3 = client("s3")
        with Stubber(s3) as stub:
            stub.add_response("list_objects_v2", {"IsTruncated": False},
                              {"Bucket": "test-bucket", "Prefix": ""})
            self.assertEqual(summarize(s3, "test-bucket"), {
                "bucket": "test-bucket", "prefix": "", "count": 0,
                "total_bytes": 0, "objects": []})
            stub.assert_no_pending_responses()

    def test_two_pages(self):
        s3 = client("s3")
        with Stubber(s3) as stub:
            stub.add_response("list_objects_v2", {
                "IsTruncated": True, "NextContinuationToken": "page2",
                "Contents": [{"Key": "reports/a.csv", "Size": 10}]},
                {"Bucket": "test-bucket", "Prefix": "reports/"})
            stub.add_response("list_objects_v2", {
                "IsTruncated": False,
                "Contents": [{"Key": "reports/b.csv", "Size": 20}]},
                {"Bucket": "test-bucket", "Prefix": "reports/", "ContinuationToken": "page2"})
            result = summarize(s3, "test-bucket", "reports/")
            self.assertEqual(result["count"], 2)
            self.assertEqual(result["total_bytes"], 30)
            self.assertEqual([x["Key"] for x in result["objects"]], ["reports/a.csv", "reports/b.csv"])
            stub.assert_no_pending_responses()

    def test_access_denied(self):
        s3 = client("s3")
        with Stubber(s3) as stub:
            stub.add_client_error("list_objects_v2", service_error_code="AccessDenied",
                                  http_status_code=403,
                                  expected_params={"Bucket": "test-bucket", "Prefix": ""})
            with self.assertRaises(ClientError) as caught:
                summarize(s3, "test-bucket")
            self.assertEqual(caught.exception.response["Error"]["Code"], "AccessDenied")
            stub.assert_no_pending_responses()

    def test_account_mismatch(self):
        sts = client("sts")
        with Stubber(sts) as stub:
            stub.add_response("get_caller_identity", {"Account": "111111111111"}, {})
            with self.assertRaises(ValueError):
                verify_account(sts, "222222222222")
            stub.assert_no_pending_responses()

    def test_no_args_no_aws_session(self):
        with patch("inventory.boto3.Session") as session, contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(main([]), 0)
            session.assert_not_called()


if __name__ == "__main__":
    unittest.main()
