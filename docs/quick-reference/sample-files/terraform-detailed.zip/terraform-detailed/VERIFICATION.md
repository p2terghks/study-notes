# 검증 결과

2026-10-13 · Terraform 1.16.5 · darwin_arm64

- HCL fmt: 통과
- local-contract init / validate: 통과
- terraform test: 5 passed, 0 failed
- 별도 임시 폴더에서 plan → 저장 계획 apply: 통과
- 같은 입력 재계획: 종료 코드 0 (변경 없음)
- 결과: 활성 서비스 2개, api-dev/web-dev, /24 subnet 2개
- 로컬 실습 state 자원 정리: 완료
- AWS 예제: 형식 확인만 수행. AWS init/plan/apply·실제 권한·비용 검증은 수행하지 않음.
