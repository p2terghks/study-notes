variable "name" { type = string }
variable "port" { type = number }
variable "replicas" { type = number }
resource "terraform_data" "service" {
  input = { name = var.name, port = var.port, replicas = var.replicas }
}
output "name" { value = var.name }
output "config" { value = terraform_data.service.output }
