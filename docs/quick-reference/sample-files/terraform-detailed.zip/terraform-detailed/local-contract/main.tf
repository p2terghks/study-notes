terraform {
  required_version = ">= 1.6, < 2.0"
}
variable "environment" {
  type    = string
  default = "dev"
  validation {
    condition     = contains(["dev", "stg", "prod"], var.environment)
    error_message = "dev, stg, prod 중 하나를 선택하세요."
  }
}
variable "services" {
  type = map(object({
    port     = number
    replicas = optional(number, 1)
    enabled  = optional(bool, true)
  }))
  default = {
    api = { port = 8080 }
    web = { port = 3000, replicas = 2 }
  }
  validation {
    condition     = alltrue([for s in values(var.services) : s.port >= 1 && s.port <= 65535 && floor(s.port) == s.port && s.replicas >= 1 && floor(s.replicas) == s.replicas])
    error_message = "port는 1~65535 정수, replicas는 1 이상 정수여야 합니다."
  }
}
locals {
  enabled = { for name, cfg in var.services : name => cfg if cfg.enabled }
  cidrs   = [for n in range(2) : cidrsubnet("10.20.0.0/16", 8, n)]
  tags    = merge({ Project = "study" }, { Environment = var.environment })
}
module "service" {
  source   = "./modules/service"
  for_each = local.enabled
  name     = lower("${each.key}-${var.environment}")
  port     = each.value.port
  replicas = each.value.replicas
}
output "service_count" { value = length(local.enabled) }
output "names" { value = sort([for m in values(module.service) : m.name]) }
output "cidrs" { value = local.cidrs }
output "tags" { value = local.tags }
output "configs" { value = { for k, m in module.service : k => m.config } }
