run "defaults" {
  command = plan
  assert {
    condition     = output.service_count == 2
    error_message = "Expected two active services"
  }
  assert {
    condition     = output.names == tolist(["api-dev", "web-dev"])
    error_message = "Unexpected names"
  }
  assert {
    condition     = output.cidrs[1] == "10.20.1.0/24"
    error_message = "Unexpected subnet calculation"
  }
}
run "production_names" {
  command = plan
  variables { environment = "prod" }
  assert {
    condition     = output.names[0] == "api-prod"
    error_message = "Environment was not passed to module"
  }
}
run "disabled_service" {
  command = plan
  variables {
    services = {
      api = { port = 8080 }
      web = { port = 3000, enabled = false }
    }
  }
  assert {
    condition     = output.service_count == 1
    error_message = "Disabled service should be filtered"
  }
}
run "reject_environment" {
  command = plan
  variables { environment = "oops" }
  expect_failures = [var.environment]
}
run "reject_port" {
  command = plan
  variables { services = { api = { port = 70000 } } }
  expect_failures = [var.services]
}
