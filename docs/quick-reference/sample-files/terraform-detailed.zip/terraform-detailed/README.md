# Terraform 상세 실습

확인일: 2026-10-13. 각 폴더는 서로 다른 Terraform root입니다.

## local-contract: 외부 계정 없이 실행

Terraform 1.6 이상. 내장 terraform_data만 사용합니다. AWS API나 provisioner를 실행하지 않습니다.

cd local-contract
terraform init -input=false
terraform fmt -check -recursive
terraform validate
terraform test
terraform plan -out=local.tfplan
terraform show local.tfplan
terraform apply local.tfplan
terraform output
terraform plan -detailed-exitcode

기본 활성 서비스 2개, 이름 api-dev/web-dev, CIDR 10.20.0.0/24와 10.20.1.0/24.
재계획은 변경 없음(종료 코드 0). 환경 변경은 terraform plan -var=environment=prod로 확인합니다.
완료 후 이 local-contract 폴더에서만 terraform destroy를 실행해 로컬 관리 항목을 정리합니다.
저장 plan apply는 추가 yes 확인 없이 실행됩니다.

## aws-storage: AWS 구성 예제

실제 적용은 수행하지 않았습니다. provider 설치와 인증, 버킷 생성 권한이 필요합니다.
Terraform 1.10 이상과 AWS provider 6.14.x 예시이며 최신 버전 선언이 아닙니다.
AWS_PROFILE로 실습 계정을 지정하고 aws sts get-caller-identity로 대상 확인 후 init/validate/plan을 실행하세요.
확인 없이 apply하지 마세요. 객체 버전과 저장 비용, 빈 버킷 삭제 조건을 고려해야 합니다.
